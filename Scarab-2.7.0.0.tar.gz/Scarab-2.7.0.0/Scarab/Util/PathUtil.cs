using System;
using System.IO;

namespace Scarab.Util
{
    public static class PathHelper
    {
        public static string GetHollowKnightPath()
        {
            // Buscamos en las carpetas de datos de los ports más conocidos de Android
            string[] paths = {
                "/sdcard/Android/data/com.TeamCherry.HollowKnight/files",
                "/storage/emulated/0/Android/data/com.TeamCherry.HollowKnight/files",
                "/sdcard/HollowKnight/files"
            };

            foreach (string path in paths)
            {
                if (Directory.Exists(path)) return path;
            }
            return "NULL";
        }

        public static string GetModPath()
        {
            string baseDir = GetHollowKnightPath();
            return baseDir != "NULL" ? Path.Combine(baseDir, "hollow_knight_Data", "Managed", "Mods") : "";
        }
    }
}

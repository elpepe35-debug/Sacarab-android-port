namespace Scarab.Models;

public enum Theme
{
    Dark,
    Light
}
namespace Scarab.Views;

[UsedImplicitly]
public partial class AboutView : ReactiveUserControl<AboutViewModel>
{
    public AboutView()
    {
        InitializeComponent();
    }
}
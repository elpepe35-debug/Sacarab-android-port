using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Scarab.Tests")]
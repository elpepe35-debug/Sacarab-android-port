# Scarab
![build](https://github.com/fifty-six/Scarab/actions/workflows/dotnet.yml/badge.svg)
![GitHub all releases](https://img.shields.io/github/downloads/fifty-six/Scarab/total)

This is a mod manager for Hollow Knight aimed at making the process of installing mods easier for users.

![screenshot](https://i.imgur.com/kWyAqX7.png)

## Usage
- Get the latest release [here](https://github.com/fifty-six/Scarab/releases/latest).
- Unzip and run it.
- Mods appear in the top left corner of the game title screen after installation.
